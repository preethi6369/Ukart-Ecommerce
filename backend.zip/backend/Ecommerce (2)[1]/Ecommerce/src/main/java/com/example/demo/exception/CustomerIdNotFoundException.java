package com.example.demo.exception;

public class CustomerIdNotFoundException extends Exception 
{
	public  CustomerIdNotFoundException(String message)
	{
		super(message);
	}

}
